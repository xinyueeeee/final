# ===================== Configuration =====================
# 'Chinese' or 'English'
dataset_name='English'

# ===================== Get Publisher Emotion Features =====================
python input_of_emotions_${dataset_name}.py